Activision and Raven are releasing this code for people to learn from and play with.
This code is copyright Activision 1996-1998
[edit 2 Sep 2008] The code is release under GNU GPLv2 (see LICENSE)

Issues:
The DMX sound library is not included with the source due to license issues,
so you won't be able to link until those sound calls are replaced or removed.
