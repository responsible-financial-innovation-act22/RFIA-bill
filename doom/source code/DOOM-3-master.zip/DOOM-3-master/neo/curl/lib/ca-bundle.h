/* This file is generated automatically */
#undef CURL_CA_BUNDLE /* unknown */
